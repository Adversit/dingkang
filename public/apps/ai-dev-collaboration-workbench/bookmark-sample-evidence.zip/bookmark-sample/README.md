# 真实执行样例：为书签列表增加标签筛选

本产物由本次「造物流程 · AI 项目交付平台」开发期间的外部执行环境生成。
源文件确实修改、测试确实运行、Git 提交确实创建；**执行发生在开发环境，不是网站执行。**
网站可以展示或下载这些预先生成的证据，但这些证据不能证明网站具有实时执行代码的能力。
本样例没有执行部署或发布，也没有发布回执。

## 需求与验收

| 需求 | 行为 | 测试覆盖 |
| --- | --- | --- |
| REQ-001 | 默认或 `all` 显示全部；选择一个标签只显示匹配条目，保留原顺序 | 默认列表、显式全部、多标签条目、完整标签匹配 |
| REQ-002 | 未知标签、无匹配、空列表返回空数组；缺少标签的旧数据不会使筛选崩溃 | 未知标签、子列表无匹配、空集合、旧数据 |
| REQ-003 | 不修改原列表、条目或标签；输出使用独立数组 | 返回数组修改、深度冻结输入、对象身份与 JSON 内容保持 |

## 使用方式

零依赖，无须安装第三方包。

```js
import { listBookmarks } from './src/bookmarks.js';

const bookmarks = [
  { id: '1', title: 'Node.js', tags: ['JavaScript', '后端'] },
  { id: '2', title: 'CSS', tags: ['前端'] },
];

listBookmarks(bookmarks);                      // 全部
listBookmarks(bookmarks, { tag: 'all' });      // 全部
listBookmarks(bookmarks, { tag: '前端' });      // id 为 2 的条目
listBookmarks(bookmarks, { tag: '未知标签' });  // []
```

`all` 是保留值。标签精确匹配，不自动去除空格或合并大小写。
返回值是新数组，条目对象仍与输入共享引用；本函数不深拷贝，也不支持修改返回条目后自动隔离原对象。

## 复现测试

```bash
node --test --test-reporter=tap test/bookmarks.test.js
```

也可以使用 `npm test`。准确的运行环境、提交 SHA、执行时间与通过数量记录在 `metadata.json`。

## 证据说明

- `evidence/before-tests.tap`：原始基线的两项测试。
- `evidence/feature-before-implementation.tap`：新增十项验收用例在旧实现上的原始输出，用于证明它们能检出功能缺失。
- `evidence/after-tests.tap`：修改后提交上的十项验收用例原始输出。
- `evidence/changes.diff`：通过真实 `git diff base_commit commit_sha` 产生的差异。
- `evidence/before-bookmarks.js`、`evidence/after-bookmarks.js`：对应提交的实现快照。
- `evidence/history.bundle`：包含前后提交的 Git 历史，可用 `git clone evidence/history.bundle audit-copy` 独立检查。
- `metadata.json`：来自真实运行和 Git 查询的元数据。

证据文件在执行完成后生成，不写入所描述的提交，避免元数据递归引用自身。
这是函数级集成样例，不包含真实用户数据、第三方服务凭据、外部仓库推送或发布操作。
