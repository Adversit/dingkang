/** Return bookmarks in their original order without mutating the input. */
export function listBookmarks(bookmarks) {
  if (!Array.isArray(bookmarks)) {
    throw new TypeError('bookmarks must be an array');
  }
  return [...bookmarks];
}
