/**
 * Return all bookmarks or bookmarks carrying one exact tag.
 * A new array is returned; bookmark objects and their tags are not modified.
 * The reserved tag "all" clears filtering. Missing tags do not match a filter.
 */
export function listBookmarks(bookmarks, { tag = 'all' } = {}) {
  if (!Array.isArray(bookmarks)) {
    throw new TypeError('bookmarks must be an array');
  }
  if (tag === 'all') return [...bookmarks];
  return bookmarks.filter(item => Array.isArray(item?.tags) && item.tags.includes(tag));
}
