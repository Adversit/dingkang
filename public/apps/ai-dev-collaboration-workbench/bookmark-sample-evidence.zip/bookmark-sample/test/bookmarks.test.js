import test from 'node:test';
import assert from 'node:assert/strict';
import { listBookmarks } from '../src/bookmarks.js';

const makeBookmarks = () => [
  { id: 'node', title: 'Node.js', url: 'https://nodejs.org/', tags: ['JavaScript', '后端'] },
  { id: 'mdn', title: 'MDN', url: 'https://developer.mozilla.org/', tags: ['JavaScript', '前端'] },
  { id: 'css', title: 'CSS', url: 'https://www.w3.org/Style/CSS/', tags: ['前端'] },
  { id: 'inbox', title: '稍后整理', url: 'https://example.org/', tags: [] },
];

test('REQ-001: default lists every bookmark in its original order', () => {
  const bookmarks = makeBookmarks();
  assert.deepEqual(listBookmarks(bookmarks), bookmarks);
});

test('REQ-001: all explicitly clears the tag filter', () => {
  const bookmarks = makeBookmarks();
  assert.deepEqual(listBookmarks(bookmarks, { tag: 'all' }), bookmarks);
});

test('REQ-001: one tag includes matching bookmarks, including multi-tag items', () => {
  const bookmarks = makeBookmarks();
  assert.deepEqual(listBookmarks(bookmarks, { tag: 'JavaScript' }).map(item => item.id), ['node', 'mdn']);
  assert.deepEqual(listBookmarks(bookmarks, { tag: '前端' }).map(item => item.id), ['mdn', 'css']);
});

test('REQ-002: an unknown tag returns an empty list', () => {
  assert.deepEqual(listBookmarks(makeBookmarks(), { tag: '不存在的标签' }), []);
});

test('REQ-002: a known tag with no matches in the current list returns empty', () => {
  const bookmarks = makeBookmarks().filter(item => item.id === 'node');
  assert.deepEqual(listBookmarks(bookmarks, { tag: '前端' }), []);
});

test('REQ-002: an empty collection stays empty for all and single-tag views', () => {
  assert.deepEqual(listBookmarks([]), []);
  assert.deepEqual(listBookmarks([], { tag: '前端' }), []);
});

test('REQ-002: bookmarks without tags are listed in all and skipped in a tag view', () => {
  const bookmarks = [{ id: 'legacy', title: 'Legacy bookmark' }, ...makeBookmarks()];
  assert.equal(listBookmarks(bookmarks).length, 5);
  assert.deepEqual(listBookmarks(bookmarks, { tag: '后端' }).map(item => item.id), ['node']);
});

test('REQ-001: matching uses the whole tag, not a substring', () => {
  assert.deepEqual(listBookmarks(makeBookmarks(), { tag: 'Java' }), []);
});

test('REQ-003: modifying the returned array leaves the source list intact', () => {
  const bookmarks = makeBookmarks();
  const result = listBookmarks(bookmarks);
  result.pop();
  assert.equal(bookmarks.length, 4);
  const filtered = listBookmarks(bookmarks, { tag: '前端' });
  filtered.reverse();
  assert.deepEqual(bookmarks.map(item => item.id), ['node', 'mdn', 'css', 'inbox']);
});

test('REQ-003: filtering deeply frozen input preserves data and item identity', () => {
  const bookmarks = makeBookmarks();
  for (const item of bookmarks) {
    Object.freeze(item.tags);
    Object.freeze(item);
  }
  Object.freeze(bookmarks);
  const before = JSON.stringify(bookmarks);
  const result = listBookmarks(bookmarks, { tag: '前端' });
  assert.deepEqual(result.map(item => item.id), ['mdn', 'css']);
  assert.equal(result[0], bookmarks[1]);
  assert.equal(result[1], bookmarks[2]);
  assert.equal(JSON.stringify(bookmarks), before);
});
